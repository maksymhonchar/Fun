"My first PyPi package" project
===============
Hello world!

Installing
============

    pip install example-publish-pypi-medium

Usage
=====

    >>> from src.logic import run
    >>> run.print_hello()
    'hello!'