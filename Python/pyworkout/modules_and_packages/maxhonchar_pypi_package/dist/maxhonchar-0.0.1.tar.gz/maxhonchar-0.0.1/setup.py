from setuptools import setup, find_packages


setup(
    name='maxhonchar',
    version='0.0.1',
    license='MIT',
    author="Max Honchar",
    author_email='maxgonchar9@gmail.com',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='https://github.com/honchardev/Fun',
    keywords='maxhonchar pypi test project',
    install_requires=[]
)
